% -*- prolog -*-
% This is a GNU Prolog program. We require GNU Prolog mostly for its
% built-in SAT solver, which is what makes all this possible. See
% <http://www.gprolog.org> for more details.
%
% Copyright (C) 2014 Alex Smith.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 2 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

% We represent a number as a list which holds 32 bits.  The most
% significant bit comes first. For a 16-bit number, the top 16 bits
% must all be zeroes.

% Mingle needs no arithmetic, so it's easiest.

mingle_inner([], [], []).
mingle_inner([H1|T1], [H2|T2], [H1,H2|T3]) :- mingle_inner(T1, T2, T3).
mingle([0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0|T1],
       [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0|T2], T3) :-
    length(T1, 16),
    length(T2, 16), !,
    mingle_inner(T1, T2, T3).

% Unary binary logic. Now with added use of =.. to remove code duplication via
% substituting in appropriate operators dynamically.

listlast([H], H).
listlast([_,H|T1], T2) :- listlast([H|T1], T2).

ubl_inner(Op, [H1,H2|T1], [H3|T2]) :-
    Eq =.. [Op, H1, H2],
    H3 #<=> Eq,
    ubl_inner(Op, [H2|T1], T2).
ubl_inner(_, [_], []).

ubl16(Op,
      [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0|T1],
      [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0|T2]) :-
    length(T1, 16),
    length(T2, 16), !,
    listlast(T1, H1),
    ubl_inner(Op, [H1|T1], T2).

or16(T1, T2) :- ubl16(`#\/`, T1, T2).
xor16(T1, T2) :- ubl16(`##`, T1, T2).
and16(T1, T2) :- ubl16(`#/\`, T1, T2).

ubl32(Op, T1, T2) :-
    length(T1, 32),
    length(T2, 32), !,
    listlast(T1, H1),
    ubl_inner(Op, [H1|T1], T2).

or32(T1, T2) :- ubl32(`#\/`, T1, T2).
xor32(T1, T2) :- ubl32(`##`, T1, T2).
and32(T1, T2) :- ubl32(`#/\`, T1, T2).

% Select is the most complex, because an output bit can depend on a
% huge number of other bits. The basic idea is to, in iselect(A,B,C),
% have one case for each combination of an AB-position and a
% C-position.

% The general implementation.
bit_in_A_corresponding_to_nth_set_bit_in_B([], [], _, 0).
bit_in_A_corresponding_to_nth_set_bit_in_B([HA|TA], [HB|TB], N, Q) :-
    fd_cardinality(TB, N2),
    ThisBit #<=> (HA #/\ HB #/\ (N #= N2)),
    bit_in_A_corresponding_to_nth_set_bit_in_B(TA, TB, N, OtherBits),
    Q #<=> (ThisBit #\/ OtherBits).
reverse_select(_, _, [], _).
reverse_select(TA, TB, [HQ|TQ], N) :-
    bit_in_A_corresponding_to_nth_set_bit_in_B(TA, TB, N, HQ),
    N2 is N+1,
    reverse_select(TA, TB, TQ, N2).

% An optimization for when the RHS is a constant.
list_fully_bound([]).
list_fully_bound([H|T]) :- non_generic_var(H), list_fully_bound(T).
set_bit_count([], 0) :- !.
set_bit_count([0|T], N) :- !, set_bit_count(T, N).
set_bit_count([1|T], N) :- !, N1 is N-1, set_bit_count(T, N1).
bit_in_A_corresponding_to_nth_set_bit_in_B_boundrhs([], [], _, 0) :- !.
bit_in_A_corresponding_to_nth_set_bit_in_B_boundrhs([HA|_], [1|TB], N, HA) :-
    set_bit_count(TB, N), !.
bit_in_A_corresponding_to_nth_set_bit_in_B_boundrhs([_|TA], [_|TB], N, Q) :-
    bit_in_A_corresponding_to_nth_set_bit_in_B_boundrhs(TA, TB, N, Q).
reverse_select_boundrhs(_, _, [], _).
reverse_select_boundrhs(TA, TB, [HQ|TQ], N) :-
    bit_in_A_corresponding_to_nth_set_bit_in_B_boundrhs(TA, TB, N, HQ),
    N2 is N+1,
    reverse_select_boundrhs(TA, TB, TQ, N2).

appropriate_reverse_select(TA, TB, TQ, N) :-
    list_fully_bound(TB), !, reverse_select_boundrhs(TA, TB, TQ, N).
appropriate_reverse_select(TA, TB, TQ, N) :-
    reverse_select(TA, TB, TQ, N).

iselect(TA, TB, TQ) :-
    % The formulae we use could potentially produce any length for the
    % result of a selection; Prolog is flexible like that. So as to
    % not get infinitely many solutions, specify the length we want in
    % advance. Likewise, we have to call reverse/2 before calling
    % reverse_select/4, or we'll make unboundedly many attempts at
    % producing a T1 which then fails to reverse due to having the
    % wrong length.
    length(TA, 32),
    length(TB, 32),
    length(TQ, 32),
    reverse(T1, TQ), !,
    appropriate_reverse_select(TA, TB, T1, 0).

% Picking a random solution. This does not pick all solutions with
% equal probability. However, each solution has some positive chance
% of being picked. I claim this fits the definition of "random", if
% not the usual one.
%
% The argument is a list of binary-format numbers.
concat([], []).
concat([H1|T1], T2) :- concat(T1, T3), append(H1, T3, T2).
random_solution(N) :-
    concat(N, N2),
    fd_labeling(N2, [variable_method(most_constrained), value_method(random)]).

% Converting numbers to/from bits.

int_binary_inner(0, [], 0) :- !.
int_binary_inner(I, [1|T], N) :-
    nonvar(I),
    I >= N, !,
    J is I - N,
    N2 is N // 2,
    int_binary_inner(J, T, N2).
int_binary_inner(I, [1|T], N) :-
    var(I), !,
    N2 is N // 2,
    int_binary_inner(J, T, N2),
    I is J + N.
int_binary_inner(I, [0|T], N) :-
    N2 is N // 2,
    int_binary_inner(I, T, N2).

int_binary(I, T) :-
    % gprolog can use very large intermediate values, but cannot parse them.
    MaxIntPlusOne is 32768 * 65536,
    int_binary_inner(I, T, MaxIntPlusOne).

% Parsing.

fd_domain_bool_list([]).
fd_domain_bool_list([H|T]) :-
    fd_domain_bool(H),
    fd_domain_bool_list(T).

varlookup([v(onespot, N, X)|_], onespot, N, X) :-
    !,
    X = [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0|T],
    length(T, 16),
    fd_domain_bool_list(T),
    !.
varlookup([v(twospot, N, X)|_], twospot, N, X) :-
    !,
    length(X, 32),
    fd_domain_bool_list(X),
    !.
varlookup([_|T], V, N, X) :- varlookup(T, V, N, X).

boundmember(H, [H|_]) :- nonvar(H).
boundmember(M, [_|T]) :- nonvar(T), boundmember(M, T).

bound_binary_vars(L, []) :- var(L).
bound_binary_vars([H|T], [H2|T2]) :-
    nonvar(H),
    H = v(_, _, H2),
    bound_binary_vars(T, T2).

spotcount(`.`, onespot).
spotcount(`:`, twospot).

% Note: This is closer to OIL syntax than INTERCAL syntax.
expr(_, X) --> [#, N], {integer(N), N >= 0, int_binary(N, X)}.
expr(V, X) --> {spotcount(Token, Type)}, [Token, N], {varlookup(V, Type, N, X)}.
expr(V, X) --> [var(`V16`)], expr(V, Y), {or16(Y, X)}.
expr(V, X) --> [?, 16], expr(V, Y), {xor16(Y, X)}.
expr(V, X) --> [&, 16], expr(V, Y), {and16(Y, X)}.
expr(V, X) --> [var(`V32`)], expr(V, Y), {or32(Y, X)}.
expr(V, X) --> [?, 32], expr(V, Y), {xor32(Y, X)}.
expr(V, X) --> [&, 32], expr(V, Y), {and32(Y, X)}.
expr(V, X) --> [punct(`(`)], expr(V, Y), [~], expr(V, Z), [punct(`)`)],
               {iselect(Y, Z, X)}.
expr(V, X) --> [punct(`(`)], expr(V, Y), [$], expr(V, Z), [punct(`)`)],
               {mingle(Y, Z, X)}.
calc(V, X, Y) --> expr(V, X), [<-], expr([], Y).

read_token_line(SorA, TokenList, EOF) :-
    read_token(SorA, Token),
    (
        (Token = punct(end_of_file), EOF = true;
         Token = punct(full_stop), EOF = false),
        !,
        TokenList = []
        ;
        TokenList = [Token | T],
        read_token_line(SorA, T, EOF)
    ).

% This predicate does one calculation, then backtracks back off the start.
% This is the only reliable way I've found in gprolog to reclaim the memory
% used.
calculate_inner :-
    read_token_line(user_input, TokenList, EOF),
    (
        calc(Vars, X, Y, TokenList, []), !
        ;
        (TokenList = []; write('E000: Parse error'), nl),
        EOF = true, stop
    ),
    (
        X = Y,
        bound_binary_vars(Vars, BinaryVars),
        random_solution(BinaryVars), !
        ;
        write('E277: Mathematical impossibility'), nl,
        EOF = true, stop
    ),
    boundmember(v(Type, N, Val), Vars),
    spotcount(Token, Type),
    int_binary(IntVal, Val),
    format('~a~d <- #~d~n', [Token, N, IntVal]),
    fail.

calculate :- randomize, repeat, calculate_inner.

% Normally, in an interactive GPL program, you need to mention that it's
% GPL on startup and give users an option to read the GPL. Luckily,
% gprolog itself (at least, the version I have) forgets to, so derivatives
% of it (like gprolog-compiled programs) don't have to either. Which is
% fortunate, because violin is normally used as a compiler backend and
% we'd need to add code to the compilers to ignore the copyright notice.
:- initialization(calculate).
